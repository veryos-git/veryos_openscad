// =====================================================================
// OMM_v2 – reference assembly built from the exported STL meshes.
// Put this file next to the kit's stl/ folder (or fix STL_DIR below).
//
// Two modes:
//   MODE = "stack"  : all parts on the common optical axis (every part in
//                     Onshape is modelled around the same origin = centre of
//                     the viewing window), exploded upwards in Z.
//   MODE = "layout" : exact positions from the Onshape assembly "OMM"
//                     (that assembly is only a loose layout – just one mate:
//                     slide FASTENED to slide_holder).
// Use this as a visual/dimensional reference while re-modelling each part
// parametrically (see omm_parts.scad).
// =====================================================================
include <omm_params.scad>

STL_DIR = "../stl/";
MODE    = "stack";   // "stack" | "layout"
EXPLODE = 25;        // mm gap between layers in stack mode

module stl(name) import(str(STL_DIR, name, ".stl"), convexity = 10);

// colours roughly matching the Onshape appearance
module table()         color("goldenrod")  stl("table__Part_1");
module y_slider()      color("dimgray")    stl("y_slider__female");
module x_slider()      color("silver")     stl("x_slider__Part_1");
module slide_holder()  color("gainsboro")  stl("slide_holder__slide_holder");
module slide()         color("lightblue", 0.5) stl("slide__slide");
module washer()        color("steelblue")  stl("washer__washer");
module shaft_adapter() color("black")      stl("motor_shaft_adapter__Part_1");

if (MODE == "stack") {
    table();
    translate([0, 0, 1*EXPLODE]) y_slider();
    translate([0, 0, 2*EXPLODE]) x_slider();
    translate([0, 0, 3*EXPLODE]) slide_holder();
    // slide sits in the 2 mm recess of the slide_holder (Onshape mate: fastened)
    translate([0, 0, 3*EXPLODE + (scl_z_slide_holder - scl_z_inset_slide_slideholder)]) slide();
} else {
    // Onshape assembly occurrence transforms (rotation = identity for all), m -> mm
    translate([123.07, -123.36, -18.03]) x_slider();       // "Part 1 <1>"
    translate([238.38, -133.46, -18.12]) y_slider();       // "female <1>"
    translate([124.07, -203.46, -20.43]) table();          // "Part 1 <2>"
    translate([152.01,  -67.28, -16.57]) slide();          // "slide <1>" (hidden in Onshape)
    translate([152.51,  -67.78, -18.57]) slide_holder();   // "slide_holder <1>"
    translate([-109.63, -128.42, -3.39]) shaft_adapter();  // "Part 1 <3>"
    translate([-121.07, -107.74, -3.39]) shaft_adapter();  // "Part 1 <4>"
    for (p = [[-32.34,-82.01,-72.66], [-12.24,-84.21,-81.88],
              [-12.02,-69.37,-66.86], [  7.30,-66.71,-70.86]])
        translate(p) washer();                             // "washer <2..5>"
}
