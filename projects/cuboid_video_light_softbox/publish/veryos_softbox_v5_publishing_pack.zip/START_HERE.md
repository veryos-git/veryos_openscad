# VeryOS video light softbox V5

The original repository folder structure is preserved so source and asset links work.

Open [the publishing guide](projects/cuboid_video_light_softbox/publish/README.md) for upload order, or [the contact sheet](projects/cuboid_video_light_softbox/publish/contact-sheet.png) for a preview.

Title, description, tags and usage notes: [listing.md](projects/cuboid_video_light_softbox/publish/listing.md).
