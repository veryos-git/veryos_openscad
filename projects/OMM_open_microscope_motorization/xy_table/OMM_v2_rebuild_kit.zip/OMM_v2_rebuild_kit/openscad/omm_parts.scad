// =====================================================================
// OMM_v2 – parametric OpenSCAD starter modules
// Reconstructed from the Onshape feature trees + sketch geometry.
// All parts share the Onshape coordinate frame: origin = centre of the
// viewing window / optical axis, Z up, part bottoms as in Onshape.
//
// Accuracy legend (checked against Onshape volumes / bounding boxes):
//   [EXACT]   volume matches Onshape within <1 %
//   [CLOSE]   main geometry right, small details (fillets, scallop phase) simplified
//   [PARTIAL] main plate only – motor bracket / drive arm details NOT modelled;
//             use the STL/STEP for those (see omm_assembly_reference.scad)
// =====================================================================
include <omm_params.scad>
$fn = 48;

// ---------- helpers --------------------------------------------------
// Row of cylindrical notches ("round removers" / pin rack) along X.
module notch_row(len, n, d, depth, z_h, from_edge_y) {
    pitch = len / (n - 1);
    for (i = [0 : n - 1])
        translate([-len/2 + i*pitch, from_edge_y + d/2 - depth, -1])
            cylinder(d = d, h = z_h + 2);
}
module rrect(size, r) {           // 2D rounded rectangle, centred
    offset(r) offset(-r) square(size, center = true);
}

// ---------- slide (glass microscope slide) [EXACT] --------------------
module omm_slide() {
    translate([0, 0, scl_z_slide/2]) cube([scl_x_slide, scl_y_slide, scl_z_slide], center = true);
}

// ---------- washer [EXACT] --------------------------------------------
module omm_washer() {
    linear_extrude(extr_washer) difference() {
        circle(d = dia_washer_outside); circle(d = dia_washer_inside);
    }
}

// ---------- rails [EXACT] ---------------------------------------------
// Profiles live in the XZ plane, rails run from y = 0 to y = -scl_z_rail.
function rail_male_profile() =   // 2 x 2 with 45° top chamfers (0.79 mm legs)
    [[-1, 0], [1, 0], [1, 1.21], [0.21, 2], [-0.21, 2], [-1, 1.21]] * (scl_x_rail/2);
// female slot = male + tol_rail/2 per side, +0.1 mm height
function rail_female_slot() =
    [[-1.1, -0.01], [1.1, -0.01], [1.1, 1.251], [0.251, 2.1], [-0.251, 2.1], [-1.1, 1.251]];

module omm_rail_male(len = scl_z_rail) {
    rotate([90, 0, 0]) linear_extrude(len) polygon(rail_male_profile());
}
module omm_rail_female(len = scl_z_rail, notches = true) {
    difference() {
        rotate([90, 0, 0]) linear_extrude(len) difference() {
            translate([-scl_x_rail_outer/2, 0]) square([scl_x_rail_outer, scl_y_rail_outer]);
            polygon(rail_female_slot());
        }
        // 24 Ø3 notches, 0.6 deep, on the -X edge only (rack / "round remover")
        if (notches)
            for (i = [0 : num_round_remover - 1])
                translate([-scl_x_rail_outer/2 - dia_round_remover_rail/2 + radius_offset_round_remover,
                           -i * len / (num_round_remover - 1), -1])
                    cylinder(d = dia_round_remover_rail, h = scl_y_rail_outer + 2);
    }
}

// ---------- slide_holder [CLOSE] --------------------------------------
// 163 x 32 x 4 plate; slide recess 77 x 26 x 2 deep; through window
// 74.6 x 23.6 (1.2 mm ledge); two handle windows 28 x 20; on the underside
// two 4.8 mm wide x 2 mm deep transverse grooves at x = ±43 that drop over
// the x_slider ring walls; Ø5 scallops 0.5 deep along both long edges.
module omm_slide_holder() {
    L   = 2*(scl_x_slide/2 + tol_slide_holder/2 + wall_slide_holder + scl_x_handle_slide_holder); // 163
    W   = scl_y_slide + tol_slide_holder + 2*wall_slide_holder;                                     // 32
    rec = [scl_x_slide + tol_slide_holder, scl_y_slide + tol_slide_holder];                         // 77 x 26
    win = rec - 2*[wall_inset_slide_holder, wall_inset_slide_holder];                               // 74.6 x 23.6
    hx0 = rec.x/2 + wall_slide_holder + wall_handle_slideholder;                                    // 47.5
    hw  = [scl_x_handle_slide_holder - 2*wall_handle_slideholder + 0, W - 2*wall_handle_slideholder]; // 28 x 20
    gw  = wall_x_slider + tol_slideh_x_slider;                                                       // 4.8
    difference() {
        linear_extrude(scl_z_slide_holder) rrect([L, W], 2.5);
        translate([0, 0, scl_z_slide_holder - scl_z_inset_slide_slideholder])
            linear_extrude(10) rrect(rec, 1);
        translate([0, 0, -1]) linear_extrude(10) rrect(win, 2.5);
        for (s = [-1, 1]) translate([s*(hx0 + hw.x/2), 0, -1]) linear_extrude(10) rrect(hw, 2.5);
        for (s = [-1, 1]) translate([s*scl_x_x_slider/2 - gw/2, -W, -1])
            cube([gw, 2*W, scl_z_inset_slideh + 1]);
        for (s = [-1, 1]) mirror([0, s < 0 ? 1 : 0, 0])
            notch_row(L - 6, 24, 5, 0.5, scl_z_slide_holder, W/2);
    }
}

// ---------- x_slider [CLOSE, volume +0.2 %] ---------------------------
// Stadium ring (slot path width 4 around an 86 x 38.2 centre-line,
// outer 90 x 42.2, r = 2 corners), 3 mm high, unioned with one female
// rail running along X at y = +scl_y_x_rail/2 (= 24.85). The rail carries
// 24 Ø3 rack notches on its outer edge (inherited from the rail part studio).
module omm_x_slider() {
    o = [scl_x_x_slider + wall_x_slider, scl_y_x_slider + wall_x_slider];   // 90 x 42.2
    i = [scl_x_x_slider - wall_x_slider, scl_y_x_slider - wall_x_slider];   // 82 x 34.2
    union() {
        linear_extrude(scl_z_x_slider) difference() { rrect(o, 2); rrect(i, 0.01); }
        // rail along +X..-X, slot facing down (toward the y_slider male rail)
        translate([-50.89 + scl_z_rail, scl_y_x_rail/2, 0]) rotate([0, 0, -90])
            translate([0, 0, scl_y_rail_outer]) mirror([0, 0, 1]) omm_rail_female(notches = true);
    }
}

// ---------- y_slider [PARTIAL] ---------------------------------------
// Frame 100 x 49.7 with 88 x 37.7 window, 2.4 mm thick (extruded downward).
// NOT modelled: male+female rails, 28BYJ-48 motor bracket (derived from
// Onshape doc "28BYJ-48_stepper_motor_bracket"), the drive arm toward -Y
// with 36 notches, fillets/chamfers. Take those from y_slider__female.stl.
module omm_y_slider_frame() {
    translate([0, 0, -scl_z_y_slider]) linear_extrude(scl_z_y_slider) difference() {
        rrect([scl_x_x_rail, scl_y_x_rail], 2.5);
        rrect([scl_x_x_rail - 2*thickness_y_slider_frame, scl_y_x_rail - 2*thickness_y_slider_frame], 2.5);
    }
}

// ---------- table / base plate [PARTIAL] -----------------------------
// Plate 100 x 130 x 3 (y from -85.15 to +44.85), window 88 x 37.7,
// Ø10 edge scallops (30, "pin_remover"), 1 mm chamfer, engraved text.
// NOT modelled: the rail and the 28BYJ-48 motor bracket uprights.
module omm_table_plate() {
    y0 = -85.15; y1 = 44.85;
    difference() {
        translate([0, (y0 + y1)/2, -scl_z_table]) linear_extrude(scl_z_table)
            rrect([scl_x_x_rail, scl_y_table], 1);
        translate([0, 0, -scl_z_table - 1]) linear_extrude(10)
            rrect([scl_x_x_rail - 2*thickness_table_frame, scl_y_x_rail - 2*thickness_table_frame], 2.5);
        // scallops (approximate pitch) on all four edges
        for (s = [-1, 1]) translate([s*(scl_x_x_rail/2 + dia_pin_remover_table/2 - 1.2), 0, 0])
            for (y = [y0 + 5 : 130/9 : y1]) translate([0, y, -5]) cylinder(d = dia_pin_remover_table, h = 10);
        for (y = [y0 - dia_pin_remover_table/2 + 1.2, y1 + dia_pin_remover_table/2 - 1.2])
            for (x = [-45 : 90/6 : 45]) translate([x, y, -5]) cylinder(d = dia_pin_remover_table, h = 10);
        // engraved label, 0.2 mm deep
        translate([-35.2, -76.15, -0.2]) linear_extrude(1) rotate(90)
            text("VeryOS", size = 5.8, font = "Liberation Sans:style=Bold");
        translate([-27.2, -76.15, -0.2]) linear_extrude(1) rotate(90)
            text("OMM v2.3", size = 5.8, font = "Liberation Sans:style=Bold");
    }
}

// ---------- motor_shaft_adapter [CLOSE, volume +7 %] ------------------
// Sleeve for the 28BYJ-48 shaft (Ø5 with 3 mm flats): OD 6.3, height 6.772,
// closed 0.772 mm top, small 45°-ish flange to r = 3.35 at the top,
// double-D bore 5.2 / 3.2 across flats, 6 mm deep. (The 3 shallow ring
// grooves and 8 Ø0.5 crush ribs of the original are omitted.)
module omm_motor_shaft_adapter() {
    h = 6.772; r_out = 3.15; r_bore = dia_motor_shaft/2 + 0.1;
    difference() {
        union() {
            cylinder(r = r_out, h = h);
            translate([0, 0, scl_z_motor_shaft]) cylinder(r1 = r_out, r2 = 3.35, h = h - scl_z_motor_shaft);
        }
        translate([0, 0, -0.01]) linear_extrude(scl_z_motor_shaft) intersection() {
            circle(r = r_bore); square([2*(slot_mshaft/2 + 0.1), 10], center = true);
        }
    }
}

// ---------- demo: lay all parts out --------------------------------
module omm_all_parts() {
    translate([0,    0, 0]) omm_table_plate();
    translate([120,  0, 0]) omm_y_slider_frame();
    translate([120, 70, 0]) omm_x_slider();
    translate([0,  110, 0]) omm_slide_holder();
    translate([0,  110, 6]) omm_slide();
    translate([-80, 0, 0])  omm_rail_male();
    translate([-70, 0, 0])  omm_rail_female();
    translate([-90, 20, 0]) omm_washer();
    translate([-90, 35, 0]) omm_motor_shaft_adapter();
}
omm_all_parts();
