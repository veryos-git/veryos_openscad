# OMM_v2 — rebuild kit for OpenSCAD

Source: Onshape document **OMM_v2** (owner "very os", public, workspace *Main*), last modified 2026‑11‑09.
URL: https://cad.onshape.com/documents/0eb8eba3ed96ab62b4c99488/w/630cc4452f8b51403d47709a
The engraved label on the base plate reads **"VeryOS / OMM v2.3"**.

## What the project is

A 3D‑printable **motorised XY microscope stage** for a standard 76 × 25 × 1 mm glass slide.
Four stacked plates share one optical axis (every part is modelled around the same origin = centre of the viewing window), and each plate slides on the one below via small printed dovetail rails. Two **28BYJ‑48 stepper motors** (brackets derived from a second Onshape document, *28BYJ‑48_stepper_motor_bracket*) carry a printed **shaft adapter** that engages rows of semicircular notches ("round removers" / "pin removers") along the moving parts. These notch rows act as a printed rack (my reading of the geometry; the document does not say so).

Stack, bottom to top:

| # | Part (part studio / part) | Role | Size (mm) | Volume (mm³) |
|---|---|---|---|---|
| 1 | `table / Part 1` | Base plate. 100 × 130 × 3 plate with an 88 × 37.7 window, a male rail, 28BYJ‑48 bracket uprights (Y motor), Ø10 edge scallops, 1 mm chamfer and engraved text | 100.1 × 130 × 32.65 | 28 951 |
| 2 | `y_slider / female` | Y carriage. 100 × 49.7 × 2.4 frame (6 mm walls, 88 × 37.7 window), a female rail running on the table and a male rail for the x_slider, its own 28BYJ‑48 bracket (X motor), and a long notched arm toward −Y (36 notches) | 100.1 × 135.6 × 29.75 | 11 019 |
| 3 | `x_slider / Part 1` | X carriage. Stadium ring 90 × 42.2 × 3 (4 mm wall) plus one 100 mm female rail along X at y = +24.85 with 24 Ø3 notches | 100 × 49.7 × 4.05 | 5 478 |
| 4 | `slide_holder / slide_holder` | Removable slide carrier. 163 × 32 × 4 plate with a 77 × 26 × 2 recess, 74.6 × 23.6 window (1.2 mm ledge), two 28 × 20 handle windows, and two 4.8 × 2 underside grooves that drop over the x_slider ring. Ø5 scallops on the long edges | 163.1 × 32.1 × 4.1 | 8 108 |
| 5 | `slide / slide` | Glass slide (reference body, hidden in the assembly) | 76 × 25 × 1 | 1 900 |
| – | `motor_shaft_adapter / Part 1` (×2) | Sleeve on the 28BYJ‑48 shaft (Ø5 with 3 mm flats). OD 6.3, 6.77 high, flange to Ø6.7, 3 shallow ring grooves, 8 crush ribs | 6.7 × 6.7 × 6.77 | 111 |
| – | `washer / washer` (×4) | Ø7 / Ø3.5 × 0.8 shim washer (M3) | 7 × 7 × 0.8 | 23 |
| – | `rail / male`, `rail / female` | Rail library part studio, derived into the parts above. Male: 2 × 2 with 45° top chamfers. Female: 7.5 × 4 block with a matching slot (+0.1 clearance per side), 24 notches Ø3 × 0.6 deep along one edge. Length 100 | 2 × 100 × 2 / 7.5 × 100 × 4 | 338 / 2 519 |

Hidden helper bodies (exported anyway): `x_slider / male`, `table / female` are copies of the rail bodies left over from derive operations.

The Onshape assembly **OMM** is only a loose layout: the parts sit side by side, and the one mate is *Fastened 1* (slide ↔ slide_holder). Instances: table, y_slider, x_slider, slide_holder, slide, 2× motor_shaft_adapter, 4× washer. There are no fasteners or motors in the BOM.

## Design notes worth knowing before you re-model

- **Everything is driven by the Variable Studio.** `openscad/omm_params.scad` is a 1:1 transcription, including derived expressions such as `scl_y_x_slider = 25 + 2·3 + 2·4 − 0.8 = 38.2` and `scl_y_x_rail = 49.7`.
- **Quarter‑modelling.** Most plates are sketched as one quarter, then mirrored twice about the Front and Right planes. The DXFs therefore often show only a quarter. Mirror them in OpenSCAD (`mirror([1,0,0])`, `mirror([0,1,0])`).
- **Rails** (`rail` part studio) are sketched on the Front plane and extruded 100 mm along −Y. They are placed into the carriages with *Transform → mate connectors*. Clearance comes from `tol_rail = 0.2` (total) and `extr_width = 0.42` (nozzle line width).
- **Notch rows.** A small circle is placed just outside an edge (slide_holder Ø5 at 0.5 depth, x_slider/rail Ø3 at 0.6 depth, table Ø10 "pin_remover"), extruded through, curve‑patterned along the edge (12 / 24 / 30 / 36 instances), and subtracted.
- **Fit between slide_holder and x_slider.** The groove width is `wall_x_slider + tol_slideh_x_slider` = 4.8 mm, so there is 0.4 mm clearance per side on the 4 mm ring wall.
- **Table feature‑tree errors.** In the `table` part studio, *Extrude 4* (intersect) and *railchamfer* currently fail (red in Onshape). The exported geometry is the regenerated state *without* those two features.
- **External dependency.** The 28BYJ‑48 bracket comes from another document (doc 2144d25958fffa26cfe48fc0, a fixed version). It is already merged into the `table` and `y_slider` solids, so the STEP/STL contain it.
- Fillets are R2.5 (`fillet_radius_small = 5` is defined but most fillets use 2.5). Chamfers are 0.2 to 1 mm at 45°.

## How to rebuild in OpenSCAD (suggested path)

1. Open `openscad/omm_assembly_reference.scad`. It imports the exported STLs either stacked on the optical axis (`MODE="stack"`) or in the original Onshape layout (`MODE="layout"`). Use it as ground truth.
2. Start from `openscad/omm_parts.scad`, which has parametric modules that already match Onshape:
   - exact: `omm_slide`, `omm_washer`, `omm_rail_male`, `omm_rail_female`
   - close: `omm_slide_holder` (−0.2 % volume), `omm_x_slider` (+0.2 %), `omm_motor_shaft_adapter` (+7 %; ring grooves and crush ribs omitted)
   - partial: `omm_y_slider_frame` and `omm_table_plate` have the plates only. Their motor brackets, the drive arm and the rails still need modelling. Use `stl/*` or the `dxf/table__Sketch_2.dxf` and `dxf/y_slider__Sketch_4.dxf` outlines.
3. For 2D profiles you can `linear_extrude(h) import("dxf/<file>.dxf", layer="0");`. Construction geometry is on layer `CONSTRUCTION` and sketch text is on `TEXT`. Coordinates are sketch‑plane coordinates in mm. Each file's 999 comment and `dxf/_index.tsv` give the plane transform. Sketches with overlapping region lines (for example `table__Sketch_1`) may need cleaning before OpenSCAD accepts them as closed polygons.
4. STEP files (`step/`) are for FreeCAD/CadQuery if you want exact B‑rep, fillets or measurements. OpenSCAD cannot import STEP.

## Folder contents

```
README.md                         this file
openscad/omm_params.scad          all Onshape variables (1:1)
openscad/omm_parts.scad           parametric starter modules (verified volumes)
openscad/omm_assembly_reference.scad   STL-based reference assembly
step/partstudio_<name>.step       every part studio (all bodies)
step/parts/<studio>__<part>.step  one STEP per part
step/assembly_OMM.step            the Onshape assembly
stl/<studio>__<part>.stl          one binary STL per part (mm, fine tessellation)
dxf/<studio>__<sketch>.dxf        every non-empty sketch (19) + _index.tsv
images/<element>_isometric.png    Onshape shaded renders (iso + top) of every part studio and the assembly
data/feature_trees_compact.md     condensed feature list of every part studio
data/features/*.json              full Onshape feature trees (parameters, sketch constraints)
data/sketches/*.json              solved sketch geometry
data/onshape_variables.json       Variable Studio
data/onshape_assembly.json        assembly instances, occurrence transforms, mates
data/onshape_bom.json             bill of materials
data/onshape_parts_bbox_volume.json   per-part bounding boxes and volumes (SI units)
```
