
## slide
- ###name = #value [assignVariable] scl_y = 40.04981 mm
- slide [newSketch] sketchPlane=Q[JDC]
- slide [extrude] operationType=NEW; endBound=BLIND; depth=#scl_z_slide; secondDirectionBound=BLIND; secondDirectionDepth=25 mm

## slide_holder
- slide_holder [newSketch] sketchPlane=Q[JDC]
- Extrude 1 [extrude] operationType=NEW; endBound=BLIND; depth=#scl_z_slide_holder; secondDirectionBound=BLIND; secondDirectionDepth=25 mm
- Extrude 2 [extrude] operationType=REMOVE; endBound=BLIND; oppositeDirection=true; depth=#scl_z_inset_slide_slideholder; startOffset=true; startOffsetEntity=Q[JHG]; secondDirectionBound=BLIND; secondDirectionDepth=25 mm
- inset [newSketch] sketchPlane=Q[JHC]
- Extrude 3 [extrude] operationType=REMOVE; endBound=BLIND; oppositeDirection=true; depth=#scl_z_inset_slideh; secondDirectionBound=BLIND; secondDirectionDepth=25 mm
- Fillet 1 [fillet] filletType=EDGE; radius=2.5 mm; nonCircularRadius=#fillet_radius_small; width=0.2 mm
- Sketch 1 [newSketch] sketchPlane=Q[JDC]
- Extrude 4 [extrude] operationType=NEW; endBound=BLIND; depth=25 mm; symmetric=true; secondDirectionBound=BLIND; secondDirectionDepth=25 mm
- Curve pattern 1 [curvePattern] patternType=PART; operationType=REMOVE; instanceFunction=BTMParameterFeatureList-1749; distance=25 mm; instanceCount=12
- mirror_base [mirror] patternType=PART; operationType=ADD; instanceFunction=BTMParameterFeatureList-1749; mirrorPlane=Q[JNS]
- mirror base [mirror] patternType=PART; operationType=ADD; instanceFunction=BTMParameterFeatureList-1749; mirrorPlane=Q[JT2]

## x_slider
- x_slider [newSketch] sketchPlane=Q[JDC]
- base [extrude] operationType=NEW; endBound=BLIND; depth=#scl_z_x_slider; secondDirectionBound=BLIND; secondDirectionDepth=25 mm
- fillet_base [fillet] filletType=EDGE; radius=2.5 mm; nonCircularRadius=5 mm; width=0.2 mm
- base [mirror] patternType=PART; operationType=ADD; instanceFunction=BTMParameterFeatureList-1749; mirrorPlane=Q[JHe]
- base [mirror] patternType=PART; operationType=ADD; instanceFunction=BTMParameterFeatureList-1749; mirrorPlane=Q[JHi]
- rails [importDerived] partStudio=REF(); placement=AT_ORIGIN
- rail_female [transform] transformType=TRANSFORM_MATE_CONNECTORS; distance=25 mm; scale=1; angle=30 deg; dx=0 mm; dy=0 mm; dz=0 mm
   - Mate connector [mateConnector] 
   - Mate connector [mateConnector] 
- part [booleanBodies] operationType=UNION; tools=Q[JHD;JeH]
- railchamfer [chamfer] chamferType=OFFSET_ANGLE; width=0.2 mm; angle=45 deg
- Sketch 1 [newSketch] sketchPlane=Q[JDC]
- Extrude 1 [extrude] operationType=NEW; endBound=BLIND; depth=25 mm; symmetric=true; secondDirectionBound=BLIND; secondDirectionDepth=25 mm
- Curve pattern 1 [curvePattern] patternType=PART; operationType=REMOVE; instanceFunction=BTMParameterFeatureList-1749; distance=25 mm; instanceCount=24

## washer
- Sketch 1 [newSketch] sketchPlane=Q[JDC]
- Extrude 1 [extrude] operationType=NEW; endBound=BLIND; depth=#extr_washer; secondDirectionBound=BLIND; secondDirectionDepth=25 mm

## motor_shaft_adapter
- ###name = #value [assignVariable] dia_motor_shaft = 5 mm
- ###name = #value [assignVariable] scl_z_motor_shaft = 6 mm
- ###name = #value [assignVariable] thick_mshaft_adapter = 0.55 mm
- revolve_profile [newSketch] sketchPlane=Q[JCC]
- Revolve 1 [revolve] operationType=NEW; axis=Q[JFN]; fullRevolve=true; endBound=BLIND; angle=30 deg
- ###name = #value [assignVariable] slot_mshaft = 3 mm
- bot_profile [newSketch] sketchPlane=Q[JDC]
- Extrude 1 [extrude] operationType=NEW; endBound=UP_TO_SURFACE; depth=25 mm; endBoundEntityFace=Q[JHa]; secondDirectionBound=BLIND; secondDirectionDepth=25 mm
- Curve pattern 1 [curvePattern] patternType=PART; operationType=NEW; instanceFunction=BTMParameterFeatureList-1749; distance=25 mm; instanceCount=8
- Extrude 2 [extrude] operationType=NEW; endBound=UP_TO_SURFACE; depth=25 mm; endBoundEntityFace=Q[JHa]; secondDirectionBound=BLIND; secondDirectionDepth=25 mm
- Delete part 1 [deleteBodies] 
- Mirror 1 [mirror] patternType=PART; operationType=ADD; instanceFunction=BTMParameterFeatureList-1749; mirrorPlane=Q[JEC]
- Revolve 2 [revolve] operationType=REMOVE; axis=Q[JFN]; fullRevolve=true; endBound=BLIND; angle=30 deg

## y_slider
- base [newSketch] sketchPlane=Q[JDC]
- base [extrude] operationType=NEW; endBound=BLIND; oppositeDirection=true; depth=#scl_z_y_slider; secondDirectionBound=BLIND; secondDirectionDepth=25 mm
- base [mirror] patternType=PART; operationType=ADD; instanceFunction=BTMParameterFeatureList-1749; mirrorPlane=Q[JHW]
- base [mirror] patternType=PART; operationType=ADD; instanceFunction=BTMParameterFeatureList-1749; mirrorPlane=Q[JIS]
- rails [importDerived] partStudio=REF(); placement=AT_ORIGIN
- railfemale [transform] transformType=TRANSFORM_MATE_CONNECTORS; distance=25 mm; scale=1; angle=30 deg; dx=0 mm; dy=0 mm; dz=0 mm
   - Mate connector [mateConnector] 
   - Mate connector [mateConnector] 
- railmale [transform] transformType=TRANSFORM_MATE_CONNECTORS; distance=25 mm; scale=1; angle=30 deg; dx=0 mm; dy=0 mm; dz=0 mm
   - Mate connector [mateConnector] 
   - Mate connector [mateConnector] 
- Sketch 4 [newSketch] sketchPlane=Q[JDC]
- Extrude 2 [extrude] operationType=REMOVE; endBound=BLIND; oppositeDirection=true; depth=25 mm; symmetric=true; secondDirectionBound=BLIND; secondDirectionDepth=25 mm
- byj_bracket [importDerived] partStudio=REF(); placement=AT_ORIGIN
- ###name = #value [assignVariable] btol = 0.3 mm
- byj bracket [transform] transformType=TRANSFORM_MATE_CONNECTORS; distance=25 mm; scale=1; angle=30 deg; dx=0 mm; dy=0 mm; dz=0 mm
   - Mate connector [mateConnector] 
   - Mate connector [mateConnector] 
- extension [extrude] operationType=NEW; endBound=UP_TO_VERTEX; depth=25 mm; secondDirectionBound=BLIND; secondDirectionDepth=25 mm
   - Mate connector [mateConnector] 
- Boolean 1 [booleanBodies] operationType=UNION; tools=Q[JdH;RBBD;JHD;JdD;RIBD]
- Fillet 1 [fillet] filletType=EDGE; radius=2.5 mm; nonCircularRadius=#fillet_radius_small; width=0.2 mm
- Sketch 1 [newSketch] sketchPlane=Q[JDC]
- Sketch 2 [newSketch] sketchPlane=Q[JDC]
- Sketch 3 [newSketch] sketchPlane=Q[SLBKB]
- Extrude 1 [extrude] operationType=REMOVE; endBound=BLIND; oppositeDirection=true; depth=25 mm; secondDirectionBound=BLIND; secondDirectionDepth=25 mm
- railchamfer [chamfer] chamferType=OFFSET_ANGLE; width=0.6 mm; angle=45 deg
- Sketch 5 [newSketch] sketchPlane=Q[JDC]
- Extrude 3 [extrude] operationType=NEW; endBound=BLIND; depth=25 mm; symmetric=true; secondDirectionBound=BLIND; secondDirectionDepth=25 mm
- Curve pattern 1 [curvePattern] patternType=PART; operationType=REMOVE; instanceFunction=BTMParameterFeatureList-1749; distance=25 mm; instanceCount=36
- Fillet 2 [fillet] filletType=EDGE; radius=2.5 mm; nonCircularRadius=5 mm; width=0.2 mm
- Chamfer 1 [chamfer] chamferType=OFFSET_ANGLE; width=1 mm; angle=45 deg

## table
- Sketch 1 [newSketch] sketchPlane=Q[JDC]
- Extrude 1 [extrude] operationType=NEW; endBound=BLIND; oppositeDirection=true; depth=#scl_z_table; secondDirectionBound=BLIND; secondDirectionDepth=25 mm
- Derived 1 [importDerived] partStudio=REF(); placement=AT_ORIGIN
- Transform 1 [transform] transformType=TRANSFORM_MATE_CONNECTORS; distance=25 mm; scale=1; angle=30 deg; dx=0 mm; dy=0 mm; dz=0 mm
   - Mate connector [mateConnector] 
   - Mate connector [mateConnector] 
- Fillet 2 [fillet] filletType=EDGE; radius=2.5 mm; nonCircularRadius=5 mm; width=0.2 mm
- Sketch 2 [newSketch] sketchPlane=Q[JDC]
- 28_byj_brack3et [importDerived] partStudio=REF(); placement=AT_ORIGIN
- Transform 2 [transform] transformType=TRANSFORM_MATE_CONNECTORS; distance=25 mm; scale=1; angle=30 deg; dx=0 mm; dy=0 mm; dz=0 mm
   - Mate connector [mateConnector] 
   - Mate connector [mateConnector] 
- Fillet 1 [fillet] filletType=EDGE; radius=2.5 mm; nonCircularRadius=5 mm; width=0.2 mm
- Extrude 2 [extrude] operationType=REMOVE; endBound=BLIND; oppositeDirection=true; depth=25 mm; symmetric=true; secondDirectionBound=BLIND; secondDirectionDepth=25 mm
- Delete part 1 [deleteBodies] 
- ###name = #value [assignVariable] chamfer_table = 1 mm
- Chamfer 1 [chamfer] chamferType=OFFSET_ANGLE; width=#chamfer_table; angle=45 deg
- ###name = #value [assignVariable] dia_pin_remover_table = 10 mm
- ###name = #value [assignVariable] overlap_remover_ = 3 mm
- Sketch 3 [newSketch] sketchPlane=Q[JDC]
- Extrude 3 [extrude] operationType=NEW; endBound=BLIND; depth=25 mm; symmetric=true; secondDirectionBound=BLIND; secondDirectionDepth=25 mm
- Curve pattern 1 [curvePattern] patternType=PART; operationType=REMOVE; instanceFunction=BTMParameterFeatureList-1749; distance=25 mm; instanceCount=30
- Extrude 4 [extrude] STATUS=ERROR operationType=INTERSECT; endBound=BLIND; depth=25 mm; secondDirectionBound=BLIND; secondDirectionDepth=25 mm
- Boolean 1 [booleanBodies] operationType=UNION; tools=Q[J5D;;JHD]
- railchamfer [chamfer] STATUS=ERROR chamferType=OFFSET_ANGLE; width=0.6 mm; angle=45 deg
- Sketch 4 [newSketch] sketchPlane=Q[RIBC]
- Extrude 5 [extrude] operationType=REMOVE; endBound=BLIND; oppositeDirection=true; depth=0.2 mm; secondDirectionBound=BLIND; secondDirectionDepth=25 mm

## rail
- male [newSketch] sketchPlane=Q[JCC]
- ###name = #value [assignVariable] workaround_no_space = 0.01 mm
- female [newSketch] sketchPlane=Q[JCC]
- parts [extrude] operationType=NEW; endBound=BLIND; depth=#scl_z_rail; secondDirectionBound=BLIND; secondDirectionDepth=25 mm
- Mirror 1 [mirror] patternType=PART; operationType=ADD; instanceFunction=BTMParameterFeatureList-1749; mirrorPlane=Q[JJy]
- dia_round_remover [newSketch] sketchPlane=Q[JLe]
- Extrude 1 [extrude] operationType=NEW; endBound=UP_TO_SURFACE; oppositeDirection=true; depth=25 mm; endBoundEntityFace=Q[JDC]; secondDirectionBound=BLIND; secondDirectionDepth=25 mm
- Curve pattern 1 [curvePattern] patternType=PART; operationType=REMOVE; instanceFunction=BTMParameterFeatureList-1749; distance=25 mm; instanceCount=#num_round_remover
